---
name: Editorial Noir Runway
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1b1b1b'
  surface-container: '#1f1f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353535'
  on-surface: '#e2e2e2'
  on-surface-variant: '#e2bdc7'
  inverse-surface: '#e2e2e2'
  inverse-on-surface: '#303030'
  outline: '#aa8891'
  outline-variant: '#5a3f47'
  surface-tint: '#ffb0c9'
  primary: '#ffb0c9'
  on-primary: '#650034'
  primary-container: '#e6007e'
  on-primary-container: '#ffffff'
  inverse-primary: '#b90064'
  secondary: '#c6c6c7'
  on-secondary: '#2f3131'
  secondary-container: '#454747'
  on-secondary-container: '#b4b5b5'
  tertiary: '#ffb1c8'
  on-tertiary: '#650033'
  tertiary-container: '#df237c'
  on-tertiary-container: '#120005'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffd9e2'
  primary-fixed-dim: '#ffb0c9'
  on-primary-fixed: '#3e001e'
  on-primary-fixed-variant: '#8e004b'
  secondary-fixed: '#e2e2e2'
  secondary-fixed-dim: '#c6c6c7'
  on-secondary-fixed: '#1a1c1c'
  on-secondary-fixed-variant: '#454747'
  tertiary-fixed: '#ffd9e2'
  tertiary-fixed-dim: '#ffb1c8'
  on-tertiary-fixed: '#3e001d'
  on-tertiary-fixed-variant: '#8e004a'
  background: '#131313'
  on-background: '#e2e2e2'
  surface-variant: '#353535'
  surface-base: '#000000'
  surface-elevated: '#111111'
  surface-card: '#181818'
  surface-interactive: '#222222'
  border-subtle: '#262626'
  border-strong: '#3F3F46'
  border-light: '#E5E5E5'
  text-primary: '#FFFFFF'
  text-muted: '#A1A1AA'
  accent-hover: '#D81B60'
  accent-glow: rgba(230, 0, 126, 0.18)
typography:
  display-hero:
    fontFamily: Montserrat
    fontSize: 64px
    fontWeight: '800'
    lineHeight: 72px
    letterSpacing: 0.08em
  display-hero-mobile:
    fontFamily: Montserrat
    fontSize: 38px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: 0.06em
  headline-lg:
    fontFamily: Montserrat
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: 0.06em
  headline-lg-mobile:
    fontFamily: Montserrat
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: 0.05em
  headline-md:
    fontFamily: Montserrat
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: 0.04em
  headline-sm:
    fontFamily: Montserrat
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0.03em
  title-md:
    fontFamily: Montserrat
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: 0.04em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: 0.01em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0.01em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-lg:
    fontFamily: Montserrat
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 18px
    letterSpacing: 0.12em
  label-md:
    fontFamily: Montserrat
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.10em
  label-sm:
    fontFamily: Montserrat
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.12em
spacing:
  gutter: 1.5rem
  gutter-mobile: 0.75rem
  margin: 3rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
  space-2xl: 4rem
  space-3xl: 6rem
---

## Brand & Style

The design system embodies the high-fashion, backstage energy of professional makeup artistry. Targeted at discerning beauty enthusiasts and professional MUAs, the aesthetic balances minimalist luxury with fearless, high-impact drama. Visuals command attention through expansive negative space, stark monochromes, and razor-sharp typographic discipline.

The visual style blends **High-Contrast Minimalism** and **Editorial Luxury**. High-voltage magenta accents punctuate an uncompromising black-and-white canvas. The interface operates like a luxury beauty monograph: precise architectural alignment, hairline framing, dramatic editorial proportions, and hyper-focused conversion funnels that honor product texture and shade fidelity.

## Colors

The palette relies on pure tonal extremes to emulate professional studio lighting:
- **Base Canvas (`#000000` / `#111111`)**: Deep studio black grounds product photography, allowing pigments and undertones to project true-to-life values without chromatic contamination.
- **Primary Accent (`#E6007E`) & Tertiary (`#FD3F92`)**: Reserved strictly for high-intent conversion pathways (Add to Bag, Checkout, Instant Filter, Shade Selector active states) and editorial badges (Pro Artist Pick, New Arrival).
- **Secondary (`#FFFFFF`)**: Crisp, stark contrast for key brand statements, high-tier navigation, and price tags.
- **Structural Grays (`#262626`, `#3F3F46`)**: Hairline dividers and structural boundaries that preserve clean spatial partitioning without adding visual weight.

## Typography

The typography couples architectural authority with flawless legibility:
- **Headings & Badges (`Montserrat`)**: Rendered in uppercase with generous letter spacing (`0.04em` to `0.12em`), referencing runway signage and high-fashion perfume packaging.
- **Body & Product Information (`Inter`)**: Engineered for frictionless scannability, shade specifications, ingredients lists, and MUA application instructions. Kept neutral and balanced to contrast against the bold geometric headlines.
- **Commerce Numbers**: Prices and shade codes use tabular numeric figures to maintain clean vertical alignments across product grids and bag drawers.

## Layout & Spacing

The layout operates on a strict **12-column fluid grid** system on desktop with structured scaling across viewports:
- **Desktop (1200px+)**: 12 columns, 24px gutters, 48px outer margins. High-density editorial product grids (4 columns per row) or hero campaigns (full-bleed 12 columns).
- **Tablet (768px - 1199px)**: 8 columns, 16px gutters, 32px outer margins. Product listings reflow to 2 or 3 columns.
- **Mobile (320px - 767px)**: 4 columns, 12px gutters, 16px outer margins. Products display in 2 columns with seamless edge-to-edge swipe containers for shade swatches and bundle galleries.

Spatial cadence relies on deliberate negative space. Editorial hero modules feature generous vertical breathing room (`space-3xl`), while purchase panels and cart interactions condense into high-velocity micro-increments (`space-xs` through `space-md`) to optimize checkout conversion.

## Elevation & Depth

Visual hierarchy rejects blurry dropshadows in favor of **Crisp Hairlines & Tonal Surface Stacking**:
- **Layer 0 (Canvas)**: `#000000` — Absolute base for hero banners and high-contrast editorial cutaways.
- **Layer 1 (Card & Section Containers)**: `#111111` — Used for PDP summary blocks, grid cards, and footer segments.
- **Layer 2 (Overlays & Drawers)**: `#181818` with a 1px border of `#262626` — Used for quick-view panels, the slide-over shopping bag, and shade-finder modals.
- **Hover & Interactive Feedback**: Highlighted surfaces shift cleanly to `#222222` with a razor-thin border shift to `#3F3F46` or an acute `#E6007E` outline. No diffused blur shadows are permitted, preserving an architectural runway look.

## Shapes

The design system enforces a uncompromising **Sharp (`roundedness: 0`)** geometry:
- **Zero Border Radius**: All buttons, inputs, product cards, dialogs, image frames, and banners have strictly squared `0px` corners. This reflects the sleek, monolithic packaging of professional makeup compacts and lipstick cases.
- **Circular Swatches Exception**: Only functional cosmetic swatches (color shade buttons, finish selectors, and undertone dots) use full circular geometry (`border-radius: 50%`) to accurately simulate liquid formula droplets and pressed pan powders.

## Components

### Buttons
- **Primary ("ADD TO BAG", "CHECKOUT")**: High-saturation `#E6007E` background, `#FFFFFF` text, `0px` radius, uppercase `Montserrat` font with `0.12em` tracking. Hover state transitions to `#D81B60` with zero elevation shift. Minimum height: 48px (touch accessible).
- **Secondary ("EXPLORE COLLECTION")**: `#000000` background, 1px solid `#FFFFFF` border, `#FFFFFF` text. Hover state inverts to `#FFFFFF` background with `#000000` text.
- **Ghost / Text**: Transparent background, `#FFFFFF` text with a 1px bottom border underline offset by 4px.

### Shade Selector & Swatches
- 36px diameter circles with a 1px border in `#262626`. Active state features a 2px outer gap followed by a 2px ring in `#E6007E`.
- Multi-finish indicator: Shimmer and metallic formulas feature subtle micro-specular visual markers within the swatch pill.

### Product Cards (e-Commerce)
- Background: `#111111`. Image ratio: 4:5 portrait orientation.
- Direct quick-add hover overlay sliding up from the bottom with a 1-tap shade carousel.
- Clear, uninhibited typography: Category badge in `label-sm` muted gray, product title in `title-md` uppercase, and price in high-contrast `#FFFFFF`.

### Chips & Filter Tags
- Squared rectangular chips (`0px` radius) in `#181818` with 1px hairline border `#262626`.
- Selected state turns the container `#FFFFFF` with `#000000` text or outlines it in `#E6007E`.

### Form Fields & Inputs
- Background: `#111111`, framed with a 1px outline in `#262626`.
- Text: `#FFFFFF`, placeholder: `#71717A`.
- Focus state: Border transitions to `#FFFFFF` or `#E6007E` with no glow ring.

### Checkboxes & Radio Buttons
- Precision 18x18px squared geometry. Inactive state: 1px border `#3F3F46`. Active state: `#E6007E` fill with crisp `#FFFFFF` checkmark or interior solid square.